<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/


// Route::get('/authtest', array('before' => 'auth.basic', function()
// {
//     return View::make('hello');
// }));

// // Route group for API versioning
// Route::group(array('prefix' => 'api/v1', 'before' => 'auth.basic'), function()
// {
//     Route::resource('url', 'UrlController');
// });

// Route::group(array('prefix' => 'admin'), function(){
//     Route::get('login', array('as' => 'admin.login', 'uses' => 'AdminAuthController@getLogin'));
//     Route::post('login', array('as' => 'admin.login.post', 'uses' => 'AdminAuthController@postLogin'));
//     Route::get('logout', array('as' => 'admin.logout', 'uses' => 'AdminAuthController@getLogout'));
// });

Route::get('/', function()
{
	
    return View::make('index');
});

Route::get('/authtest', array('before' => 'auth.basic', function()
{
    return View::make('hello');
}));

// Route group for API versioning
// Route::group(array('prefix' => 'api/v1', 'before' => 'auth.basic'), function()
// {
//     Route::resource('member', 'MemberController');
// });




Route::group(['prefix' => 'admin', 'before' => 'auth.basic'], function() {
	// Route::group(['prefix' => 'admin', 'after' => 'allowOrigin'], function() {

		Route::post('/login', function () {
			$dashboard = Dashboard::get();
        	return Response::json(['status' => 200,'dashboard' => $dashboard->toArray()
        	]);
	    });

	    Route::get('/all-members', function () {
	    	$members = Member::where('status', '1')->get();
        	return Response::json(['status' => 200, 'members' => $members->toArray()
        	]);
	    });

	    Route::post('/remove-member/{id}', function ($id) {
	        $member = Member::find($id);
	        $member->delete();

	        return Response::json(['status' => 200, 'mesg' => 'member deleted'
	        ]);	 
	    });

	    Route::get('/join-requests', function () {
	    	$members = Member::where('status', '0')->get();
        	return Response::json(['status' => 200, 'members' => $members->toArray()
        	]);
	    });

	    // Route::post('/join-requests/accept/{id}', function ($id) {
	    // 	$member = new Member;
	    // 	$member->member = Request::get(id);
	    // 	$member->status = '1';
	    	
		   //  $member->save();

     //    	return Response::json(['status' => 200, 'mesg' => 'member added'
     //    	]);
	    // });

	    // Route::post('/join-requests/accept/{id}', function ($id) {
	    // 	$members = Member::where('id', Request::get('id'));
	    // 	$member->status = '1';
	    	
		   //  $member->save();

     //    	return Response::json(['status' => 200, 'mesg' => 'member added'
     //    	]);
	    // });



	    Route::post('join-requests/{id}/option', function ($id) {
	    	$option = Input::get('option');
			
			$members = Member::find($id);



	    	if($option == 'accept')
	    	{    	
	    		$members->status='1';
	    		$members->save();

	    		return Response::json(['status' => 200, 'mesg' => 'membership request accepted']);
	    	}
	    	elseif($option == 'reject')
	    	{
	    		$members->delete();
	    		
	    		return Response::json(['status' => 200, 'mesg' => 'membership request rejected']);
	    	}

	    	
        });


	    // Route::post('/join-requests/reject/{id}', function ($id) {
	    // 	$members = Member::where('id', Request::get('id'))->find($id);
	    	
		   //  $member->delete();

     //    	return Response::json(['status' => 200, 'mesg' => 'member rejected'
     //    	]);
	    // });

	    Route::get('/community-settings', function () {
			$settings = Settings::get();
        	return Response::json(['status' => 200,'settings' => $settings->toArray()
        	]);
	    });

	  //   Route::put('/community-settings', function () {
	  //   	$settings = new Settings;
		 //    $settings->color1 = Request::get('color1');
		 //    $settings->color2 = Request::get('color2');
		 //    $settings->color3 = Request::get('color3');
		 //    $settings->welcome_logo = Request::get('welcome_logo');
			// $settings->app_header = Request::get('app_header');
		 //    $settings->settings = Request::get('menu_header');
		 
		 //    $settings->save();

   //      	return Response::json(['status' => 200, 'mesg' => 'settings updated'
   //      	]);
	  //   });



	    Route::put('/community-settings/{id}', function ($id) {
			// $settings = new Settings;
			$settings = Settings::find($id);
			// # = %23

		 	//return Response::json(  print_r(Input::all()) );
		    if ( Request::get('color1') )
		    {
		        $settings->color1 = Request::get('color1');
		    }
		 
		    if ( Request::get('color2') )
		    {
		        $settings->color2 = Request::get('color2');
		    }

		    if ( Request::get('color3') )
		    {
		        $settings->color3 = Request::get('color3');
		    }

		    if ( Request::get('welcome_logo') )
		    {
		        $settings->welcome_logo = Request::get('welcome_logo');
		    }

		    if ( Request::get('app_header') )
		    {
		        $settings->app_header = Request::get('app_header');
		    }

		    if ( Request::get('menu_header') )
		    {
		        $settings->settings = Request::get('menu_header');
		    }
		 
		    $settings->save();

        	return Response::json(['status' => 200, 'mesg' => 'settings updated'
        	]);
	    });


	    // Route::post('/join-requests/reject/{id}', function ($id) {
	    // 	$members = Member::where('status', '0')->find($id);

		   //  if ( Request::get('id') = $member->id )
		   //  {
		   //      $member->status = 1;
		   //  }
		   //  $member->save();

     //    	return Response::json(['status' => 200, 'mesg' => 'member rejected'
     //    	]);
	    // });

	// });
});
