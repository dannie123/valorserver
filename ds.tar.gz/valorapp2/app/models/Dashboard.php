<?php
 
class Dashboard extends Eloquent {
 
    protected $table = 'dashboard';
 
}