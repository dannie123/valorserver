<?php
 
class Member extends Eloquent {
 
    protected $table = 'members';
 
}