<?php
 
class Settings extends Eloquent {
 
    protected $table = 'settings';
 
}